import { useState, useRef, useEffect } from 'react';
import { PROBLEMS } from '../shared/problems.js';
import { STAGES } from '../shared/rmt.js';

export default function App() {
  const [pid, setPid] = useState(PROBLEMS[0].id);
  const [stage, setStage] = useState(1);
  const [hint, setHint] = useState(1);
  const [chats, setChats] = useState({});
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);
  const problem = PROBLEMS.find(p => p.id === pid);
  const msgs = chats[pid] || [];
  useEffect(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), [msgs, loading]);

  async function send(text, nextHint = hint) {
    if (!text.trim() || loading) return;
    const updated = [...msgs, { role: 'user', content: text }];
    setChats(c => ({ ...c, [pid]: updated }));
    setInput(''); setLoading(true);
    try {
      const r = await fetch('/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: updated, problemId: pid, stageId: stage, hintLevel: nextHint })
      });
      const d = await r.json();
      const reply = r.ok ? d.reply : '⚠️ ' + (d.error || 'Terjadi kesalahan.');
      setChats(c => ({ ...c, [pid]: [...updated, { role: 'assistant', content: reply }] }));
    } catch {
      setChats(c => ({ ...c, [pid]: [...updated, { role: 'assistant', content: '⚠️ Tidak bisa terhubung ke server.' }] }));
    }
    setLoading(false);
  }
  function needHelp() {
    const lv = Math.min(hint + 1, 3);
    setHint(lv);
    send('Saya masih bingung, tolong beri petunjuk.', lv);
  }
  const pick = (id) => { setPid(id); setStage(1); setHint(1); };

  return (
    <div className="wrap">
      <h1>🛍️ Belajar Harga Jual & Harga Beli</h1>
      <div className="tabs">
        {PROBLEMS.map((p, i) => (
          <button key={p.id} className={p.id === pid ? 'on' : ''} onClick={() => pick(p.id)}>Soal {i + 1}</button>
        ))}
      </div>
      <div className="card">
        <small>{problem.indikator}</small>
        <h3>{problem.judul}</h3>
        <p>{problem.teks}</p>
      </div>
      <div className="stages">
        {STAGES.map(s => (
          <button key={s.id} className={s.id === stage ? 'on' : s.id < stage ? 'done' : ''} onClick={() => { setStage(s.id); setHint(1); }}>
            {s.id}. {s.nama}
          </button>
        ))}
      </div>
      <div className="chat">
        {msgs.length === 0 && <p className="muted">Pilih tahap RMT, lalu ceritakan apa yang kamu pahami dari soal. Asisten akan membimbingmu, bukan memberi jawaban. 😊</p>}
        {msgs.map((m, i) => <div key={i} className={'bubble ' + m.role}>{m.content}</div>)}
        {loading && <div className="bubble assistant">Sedang berpikir…</div>}
        <div ref={endRef} />
      </div>
      <div className="row">
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send(input)} placeholder="Tulis jawaban atau pertanyaanmu…" />
        <button onClick={() => send(input)} disabled={loading}>Kirim</button>
      </div>
      <button className="help" onClick={needHelp} disabled={loading}>💡 Saya bingung, beri petunjuk (level {hint}/3)</button>
    </div>
  );
}
