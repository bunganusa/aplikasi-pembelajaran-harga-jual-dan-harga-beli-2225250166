// Dipakai otomatis oleh Vercel sebagai serverless function.
export { default } from '../server/chat.js';
