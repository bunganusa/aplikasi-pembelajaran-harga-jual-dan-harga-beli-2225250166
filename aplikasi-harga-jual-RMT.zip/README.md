# Aplikasi Pembelajaran Harga Jual (RMT + AI)

## Jalankan di VS Code
1. Buka folder ini di VS Code, lalu terminal: `npm install`
2. Salin `.env.example` jadi `.env`, isi `AI_API_KEY` (DeepSeek / AI gratis lain).
3. `npm run dev` lalu buka http://localhost:5173

## Keamanan API key (arahan dosen)
Key hanya dibaca di backend (`server/chat.js`) dari `.env`. `.env` sudah ada di `.gitignore`, jangan di-commit.
Di Vercel: Settings > Environment Variables > tambah `AI_API_KEY` (dan `AI_BASE_URL`, `AI_MODEL` jika bukan DeepSeek), lalu redeploy.

## Yang WAJIB disesuaikan
- `shared/rmt.js` : samakan tahapan dengan ringkasan RMT dari SPADA.
- (Sudah terisi soal & kisi-kisi Bunga Nusa Pertiwi di `shared/problems.js` + `server/kunci.js`. Ganti jika dosen merevisi.)

## Struktur
- `shared/rmt.js` tahapan RMT + prompt pedagogis (cognitive load intrinsic/extraneous/germane)
- `server/chat.js` proxy ke AI (dipakai lokal via Express dan di Vercel via `api/chat.js`)
- `src/App.jsx` tampilan soal, stepper RMT, chatbot

## Commit ke repo lama (jangan buat repo baru)
`git add . && git commit -m "feat: integrasi AI + model RMT" && git push`
