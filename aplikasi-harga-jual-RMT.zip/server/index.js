import 'dotenv/config';
import express from 'express';
import chat from './chat.js';
const app = express();
app.use(express.json());
app.post('/api/chat', chat);
app.listen(3001, () => console.log('API jalan di http://localhost:3001'));
