// Khusus server (tidak masuk bundle frontend). Sumber: kisi-kisi Bunga Nusa Pertiwi.
export const KUNCI = {
  p1: 'T1 info: harga beli total 300.000, 20 kg, harga jual 16.000/kg dan 17.000/kg. T2 Toko A: 20x16.000=320.000, untung 20.000. T3 Toko B: 20x17.000=340.000, untung 40.000. T4 bandingkan 40.000>20.000. T5 Toko B lebih untung (asumsi semua terjual, tanpa biaya lain).',
  p2: 'T1 diketahui harga jual 120.000, untung 20% dari harga beli; ditanya harga beli. T2 misal harga beli = x. T3 harga jual = 100%+20% = 120% dari harga beli. T4 model: 1,2x = 120.000. T5 x = 120.000 : 1,2 = 100.000. T6 harga beli Rp100.000; persentase untung dari harga beli, bukan harga jual.',
  p3: 'T1 harga beli 800.000, harga jual 680.000. T2 harga jual < harga beli maka rugi. T3 rugi = beli - jual = 120.000. T4 persen rugi = 120.000/800.000 x 100% = 15%. T5 rugi Rp120.000 dan 15%.',
  p4: 'T1 beli 150.000, jual 180.000. T2 untung = 30.000. T3 persen untung dihitung dari harga beli. T4 30.000/150.000 x 100% = 20%. T5 cara Rani salah karena pembagi harga jual. T6 persen untung benar 20% dari harga beli.'
};
