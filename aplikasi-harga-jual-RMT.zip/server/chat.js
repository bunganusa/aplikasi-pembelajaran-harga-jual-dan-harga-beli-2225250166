import { buildSystemPrompt } from '../shared/rmt.js';
import { PROBLEMS } from '../shared/problems.js';
import { KUNCI } from './kunci.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const key = process.env.AI_API_KEY || process.env.DEEPSEEK_API_KEY;
  if (!key) return res.status(500).json({ error: 'API key belum diatur (.env / Environment Variables).' });

  const { messages = [], problemId, stageId = 1, hintLevel = 1 } = req.body || {};
  const problem = PROBLEMS.find(p => p.id === problemId);
  if (!problem) return res.status(400).json({ error: 'Soal tidak ditemukan.' });

  const history = messages
    .filter(m => ['user', 'assistant'].includes(m.role) && typeof m.content === 'string')
    .slice(-12)
    .map(m => ({ role: m.role, content: m.content.slice(0, 1500) }));

  const system = buildSystemPrompt({ problem, kunci: KUNCI[problemId], stageId: Number(stageId), hintLevel: Number(hintLevel) });
  const base = process.env.AI_BASE_URL || 'https://api.deepseek.com';
  const model = process.env.AI_MODEL || 'deepseek-chat';

  try {
    const r = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model, temperature: 0.4, max_tokens: 400, messages: [{ role: 'system', content: system }, ...history] })
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data?.error?.message || 'AI error' });
    return res.status(200).json({ reply: data.choices?.[0]?.message?.content || '' });
  } catch (e) {
    return res.status(500).json({ error: 'Gagal menghubungi AI.' });
  }
}
